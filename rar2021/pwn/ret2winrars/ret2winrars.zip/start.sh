#/bin/bash
cd challenge/
timeout 30 ./ret2winrars
