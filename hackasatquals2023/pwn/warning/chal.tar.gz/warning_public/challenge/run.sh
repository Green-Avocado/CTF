#!/bin/bash

./warning