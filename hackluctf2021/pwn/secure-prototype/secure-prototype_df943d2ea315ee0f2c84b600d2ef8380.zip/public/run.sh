#!/bin/sh

qemu-arm -L /usr/arm-linux-gnueabi ./challenge.elf
